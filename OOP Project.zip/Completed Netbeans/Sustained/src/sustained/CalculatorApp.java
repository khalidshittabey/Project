/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sustained;


public class CalculatorApp {
    private Calculator calculator;

    // Additional fields to store values from CalculatorForm
    private double num1;
    private double num2;
    private double result;

    public CalculatorApp() {
        this.calculator = new Calculator();
    }

    // Other methods and logic related to the CalculatorApp can be added here

    public Calculator getCalculator() {
        return calculator;
    }

    public void setNum1(double num1) {
        this.num1 = num1;
    }

    public void setNum2(double num2) {
        this.num2 = num2;
    }

    public double getNum1() {
        return num1;
    }

    public double getNum2() {
        return num2;
    }

    // Methods to perform calculations and update result
    public void performAddition() {
        result = num1 + num2;
    }

    public void performSubtraction() {
        result = num1 - num2;
    }

    public void performMultiplication() {
        result = num1 * num2;
    }

    public void performDivision() {
       
        if (num2 != 0) {
            result = num1 / num2;
        } else {
            System.err.println("Error: Division by zero");
        }
    }

    public double getResult() {
        return result;
    }

    public static void main(String[] args) {
        CalculatorApp calculatorApp = new CalculatorApp();

      
        calculatorApp.setNum1(5.0);
        calculatorApp.setNum2(3.0);

     
        calculatorApp.performAddition();
        calculatorApp.performSubtraction();
        calculatorApp.performMultiplication();
        calculatorApp.performDivision();

        
        System.out.println("Result: " + calculatorApp.getResult());
    }
}