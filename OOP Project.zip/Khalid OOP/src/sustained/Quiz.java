/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sustained;

/**
 *
 * @author bxstx
 */

// Quiz.java
import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;

public class Quiz {
    private String[] questions;
    private String[][] options;
    private int index;
    private int correct;
    private ButtonGroup bg;

    public Quiz() {
        
            }

    public void displayQuestion() {
       
    }

    public void getSelectedOption(JRadioButton rbtn) {
        
    }

    public void enableRbuttons(boolean yes_or_no) {
        
    }

    public void restartQuiz() {
       
    }

    public void displayScore() {

    }

    public int getCorrectAnswers() {
        return correct;
    }
}